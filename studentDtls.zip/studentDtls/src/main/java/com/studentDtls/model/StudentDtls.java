package com.studentDtls.model;

public class StudentDtls {
	
	private Integer sno;
	private String std_name;
	private String sub;
	private String marks;
	private String Flag;
	
	
	public Integer getSno() {
		return sno;
	}
	public void setSno(Integer sno) {
		this.sno = sno;
	}
	public String getStd_name() {
		return std_name;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getFlag() {
		return Flag;
	}
	public void setFlag(String flag) {
		Flag = flag;
	}
	@Override
	public String toString() {
		return "StudentDtls [sno=" + sno + ", std_name=" + std_name + ", sub=" + sub + ", marks=" + marks + ", Flag="
				+ Flag + "]";
	}
	

}
