package com.studentDtls.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StudentDtlsMapper implements RowMapper<StudentDtls> {
	
	public StudentDtls mapRow(ResultSet rs, int rowNum) throws SQLException {
		StudentDtls student = new StudentDtls();
		student.setSno(rs.getInt("sno"));
		student.setStd_name(rs.getString("std_name"));
		
		
		return student;
		

}
}
