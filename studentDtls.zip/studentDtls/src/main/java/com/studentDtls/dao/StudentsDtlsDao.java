package com.studentDtls.dao;

import java.util.List;

//import org.springframework.ui.Model;

import com.studentDtls.model.StudentDtls;

public interface StudentsDtlsDao {
	
	public StudentDtls getStudentDtls(Integer id);
	public List<StudentDtls> getStudentAllDtls();
	public void insertStudent (StudentDtls std);
	public int deleteStudent (int id);
	
	
	public void updateStudent(int id, StudentDtls model);

}
