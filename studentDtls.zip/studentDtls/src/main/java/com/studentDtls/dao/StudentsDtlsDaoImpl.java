package com.studentDtls.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.ui.Model;

import com.studentDtls.model.StudentDtls;

import com.studentDtls.model.StudentDtlsMapper;


public class StudentsDtlsDaoImpl implements StudentsDtlsDao {
	
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	 public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }

	public StudentDtls getStudentDtls(Integer id) {
		String sql = "select sno,std_name from "
				+ " student_dtls "
			   + "  where sno = ? ";
		StudentDtls student = jdbcTemplateObject.queryForObject(sql, new Object[] {id},new StudentDtlsMapper());
				return student;
		
	}

	public List<StudentDtls> getStudentAllDtls() {
		String sqlstr;
		
		
		sqlstr = new String("select sno,std_name from student_dtls");
		
		//sqlstr.append("select sno,std_name from   student_dtls");
		List<StudentDtls> studentAll = jdbcTemplateObject.query(sqlstr,new Object[] {},new StudentDtlsMapper());
		
		return studentAll;
	}

	public void insertStudent(StudentDtls std) {
	
		String str =  new String("insert into student_dtls (sno,STD_NAME,SUBJECT,MARKS,IS_ACTIVE) values("+std.getSno()+",'"+std.getStd_name()+"','"+std.getSub()+"','"+std.getMarks()+"','"+std.getFlag()+"')");
		jdbcTemplateObject.update(str);
		
	}

	public int deleteStudent(int id) {

		String str = new String("DELETE FROM student_dtls WHERE SNO = ? ");
		
		int result = jdbcTemplateObject.update(str, new Object[] {id});
		
		return result;
		
	}

	public void updateStudent(int id) {
	
	
	
	
		
	}

	public void updateStudent(int id, StudentDtls model) {
		
		
		/*
		 * StudentDtls obj = new StudentDtls(); model.addAttribute(obj);
		 */
	
		String sql = new String("UPDATE student_dtls"
				+ "	SET STD_NAME = '"+model.getStd_name()+"' "
				+ " WHERE SNO = ? ");
		jdbcTemplateObject.update(sql, new Object[] {id});
		
	}

	

}
