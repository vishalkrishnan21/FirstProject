package com.studentDtls.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.studentDtls.exception.DataNotFoundException;
import com.studentDtls.model.StudentDtls;
import com.studentDtls.service.StudentDtlsService;


@RestController
public class StudentDtlsController {
	
	
	@Autowired
	StudentDtlsService studentDtlsService;
	
	
	@RequestMapping(value = "/")
	public String displayHello(ModelMap model)
	{
		model.addAttribute("message","Hello Student");
		return "helloStudent";
	}
		
    @RequestMapping(value="student/{id}",method = RequestMethod.GET)
    public String getStudent(@PathVariable("id") int id, Model model)
    {
    	
    StudentDtls student = 
    		studentDtlsService.getStudentDtls(id);
    
    model.addAttribute("students", student);
    	
    return "jsonTemplate"+student.getStd_name();
    }
    
    @RequestMapping(value="student",method = RequestMethod.GET)
    public @ResponseBody List<StudentDtls> getStudentAll()
    {    
    List<StudentDtls> student = 
    		studentDtlsService.getStudentAllDtls();   
    return student;
    
    
    }
       
    @RequestMapping(value = "/student",method = RequestMethod.POST)
    public String getInsertStudent(@RequestBody StudentDtls std) throws DataIntegrityViolationException
    {
    	studentDtlsService.insertStudent(std);
    	return "student is inserted";    	
    }

    @RequestMapping(value = "student/{id}", method = RequestMethod.DELETE) 
    public String deleteStudent(@PathVariable("id") int id) throws DataNotFoundException
    {
    	int result = studentDtlsService.deleteStudent(id);
    	if(result == 0)
    	{
    		throw new DataNotFoundException("No Data Found");
    	}
    	return "sno :"+id+" is Deleted";
    }
    
    @RequestMapping(value = "student/{id}", method=RequestMethod.PUT)
    public String updateStudent(@PathVariable("id") int id ,@RequestBody StudentDtls model)
    {
    studentDtlsService.updateStudent(id,model);
    return "sno :"+id+" is Updated";
    }
    
	/*
	 * @RequestMapping(value = "student/test/{StudentNm}",method =
	 * RequestMethod.GET) public ResponseEntity<StudentDtls>
	 * showMessage(@PathVariable("StudentNm") String StudentNm,
	 * 
	 * @RequestParam(value ="sno", required = false, defaultValue = "0000") final
	 * int sno) throws StudentException { StudentDtls std =new StudentDtls();
	 * std.setSno(sno); std.setStd_name(StudentNm);
	 * 
	 * if (1 == 1) { throw new StudentException("Invalid employee name requested");
	 * } return new ResponseEntity<StudentDtls>(std, HttpStatus.OK); }
	 * 
	 * @ExceptionHandler(StudentException.class) public
	 * ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) { ErrorResponse
	 * error = new ErrorResponse();
	 * error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());
	 * error.setMessage(ex.getMessage()); return new
	 * ResponseEntity<ErrorResponse>(error, HttpStatus.OK); }
	 */	  
	 

    
}
