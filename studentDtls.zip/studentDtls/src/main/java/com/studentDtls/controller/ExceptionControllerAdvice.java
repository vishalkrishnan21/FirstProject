package com.studentDtls.controller;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.studentDtls.exception.DataNotFoundException;
import com.studentDtls.model.ErrorResponse;

@ControllerAdvice
public class ExceptionControllerAdvice {
 
   @ExceptionHandler(Exception.class)
   public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
       ErrorResponse error = new ErrorResponse();
       error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
       error.setMessage(ex.getMessage());
       return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
   }
   @ExceptionHandler(DataIntegrityViolationException.class)
   public ResponseEntity<ErrorResponse> dataIntegrityHandler(Exception ex) {
       ErrorResponse error = new ErrorResponse();
       error.setErrorCode(HttpStatus.BAD_REQUEST.value());
       error.setMessage(ex.getMessage());
       return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
   }
   
   @ExceptionHandler(DataNotFoundException.class)
   public ResponseEntity<ErrorResponse> noDataFoundHandler(Exception ex) {
       ErrorResponse error = new ErrorResponse();
       error.setErrorCode(HttpStatus.CONFLICT.value());
       error.setMessage(ex.getMessage());
       return new ResponseEntity<ErrorResponse>(error, HttpStatus.CONFLICT);
   }
   
   
}
