package com.studentDtls.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.ui.Model;

import com.studentDtls.dao.StudentsDtlsDao;

import com.studentDtls.model.StudentDtls;

@Service
public class StudentsDtlsServiceImpl implements StudentDtlsService {

	@Autowired
	 StudentsDtlsDao studentsDtlsDao;
	
	public StudentDtls getStudentDtls(int id) {
		
		return studentsDtlsDao.getStudentDtls(id) ;
	}

	public List<StudentDtls> getStudentAllDtls() {
		// TODO Auto-generated method stub
		return  studentsDtlsDao.getStudentAllDtls() ;
	}

	public void insertStudent(StudentDtls std) {
		// TODO Auto-generated method stub
		 studentsDtlsDao.insertStudent(std);
	}

	public int deleteStudent(int id) {
		return studentsDtlsDao.deleteStudent(id);		
	}

	
	public void updateStudent(int id, StudentDtls model) {
		 studentsDtlsDao.updateStudent(id,model);
	}

}
